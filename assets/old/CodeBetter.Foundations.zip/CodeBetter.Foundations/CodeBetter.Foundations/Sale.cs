﻿namespace CodeBetter.Foundations
{
   using System;

   public class Sale
   {
      private int _id;
      private Model _model;
      private SalesPerson _salesPerson;
      private DateTime _dated;
      private double _price;

      public int Id
      {
         get { return _id; }
      }
      public Model Model
      {
         get { return _model; }
         set { _model = value; }
      }
      public SalesPerson SalesPerson
      {
         get { return _salesPerson; }
         set { _salesPerson = value; }
      }
      public DateTime Dated
      {
         get { return _dated; }
         set { _dated = value; }
      }
      public double Price
      {
         get { return _price; }
         set { _price = value; }
      }

      public Sale() {}
      public Sale(Model model, SalesPerson salesPerson, DateTime dated, double price)
      {
         _model = model;
         _salesPerson = salesPerson;
         _dated = dated;
         _price = price;
      }
   }
}
