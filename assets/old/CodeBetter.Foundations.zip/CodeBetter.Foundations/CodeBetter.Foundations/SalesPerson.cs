﻿namespace CodeBetter.Foundations
{
   using System;
   using System.Collections.Generic;
   
   public class SalesPerson
   {
      private string _firstName;
      private int _id;
      private bool _isActive;
      private string _lastName;
      private DateTime _startDate;
      private IList<Sale> _sales;

      public int Id
      {
         get { return _id; }
      }
      public string FirstName
      {
         get { return _firstName; }
         set { _firstName = value; }
      }
      public string LastName
      {
         get { return _lastName; }
         set { _lastName = value; }
      }
      public string Alias
      {
         get { return _firstName.Substring(0, 1) + _lastName; }
      }
      public DateTime StartDate
      {
         get { return _startDate; }
         set { _startDate = value; }
      }
      public bool IsActive
      {
         get { return _isActive; }
         set { _isActive = value; }
      }
      public IList<Sale> Sales
      {
         get { return _sales; }
      }

      public SalesPerson() {}
      public SalesPerson(string firstName, string lastName, bool isActive, DateTime startDate)
      {
         _firstName = firstName;
         _isActive = isActive;
         _lastName = lastName;
         _startDate = startDate;
      }

      //NHibernate will not automatically wire-up bidirectional relationships. In other words,
      //if we didn't have this method and simply did : salesPerson.Sale.Add(sale);
      //then sale.SalesPerson would be null.
      //It's a common pattern to create AddXXX methods to set this up as you see below.     
      public void AddSales(Sale sale)
      {
         
         if (sale.SalesPerson != null)
         {  
            //if this sale already had a salesperson, remove that person from the sale
            //(the system currently doesn't support multiple salespeople per sale)
            sale.SalesPerson.RemoveSale(sale);
         }
         _sales.Add(sale);
         sale.SalesPerson = this;
      }

      public void RemoveSale(Sale sale)
      {
         _sales.Remove(sale);
      }
   }
}