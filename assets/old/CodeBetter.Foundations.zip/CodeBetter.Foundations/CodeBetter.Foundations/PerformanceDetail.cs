﻿namespace CodeBetter.Foundations
{
   public class PerformanceDetail
   {
      private double _totalSales;
      private string _firstName;
      private string _lastName;
      public double TotalSales
      {
         get { return _totalSales; }
      }

      public string FirstName
      {
         get { return _firstName; }
      }

      public string LastName
      {
         get { return _lastName; }
      }

      public PerformanceDetail(string firstName, string lastName, double totalSales)
      {
         _totalSales = totalSales;
         _firstName = firstName;
         _lastName = lastName;
      }
   }
}
