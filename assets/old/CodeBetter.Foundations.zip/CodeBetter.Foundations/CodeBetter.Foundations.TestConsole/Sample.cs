﻿//Even though we aren't doing it here, don't forget the lessons from part 4 and 5.
//Ideally, you'd abstract your data access logic behind an interface and programming against
//it - allowing you to easily create a mock or stub.

//So in reality, for the function LetsFindBellware, we'd likely do something like:
//SalesPerson bellware = SalesPerson.FindById(1);
//
//and FindById would look like:
//
//public static SalesPerson FindById(int salesPersonId)
//{
//    if (salesPersonId <= 0)
//    {
//       //maybe we should throw in InvalidArgumentException instead?
//       return null;
//    }
//    IDataProvider provider = DataProvider.CreateInstance; //this uses StructureMap to return our IDataProvider instance
//    return provider.FindById(salesPersonId);
//}


namespace CodeBetter.Foundations.TestConsole
{
   using System;
   using System.Collections.Generic;
   using System.Diagnostics;
   using log4net;
   using NHibernate;
   using NHibernate.Cfg;

   public class Sample
   {
      private static ILog log = LogManager.GetLogger("Programm");
      private static ISessionFactory _sessionFactory;

      public Sample()
      {
         //The SessionFactory is thread-safe, meaning you should ever only need one per application 
         //(regardless of whether it's a multi-user (ASP.NET) application or not. The only time you'll 
         //require multiple SessionFactories is when connecting to multiple databases, in this case you'd have
         //one SessionFactory per database.

         //The purpose of the SessionFactory is to provide us instances of ISessions, which are the work-horse 
         //of NHibernate. An ISession is a short-live thread-specific object that represents communication with
         //the database. For now, you can losely think of ISession as Connections - except that opening an ISession
         //won't necessarily open a connection, NHibernate smartly manages and opens connections as needed and for optimal
         //use. In other words, open-late and close-early isn't really applicable to ISessions.;;;;;;;;;;;;;;;;;;;;/5tttr         
         _sessionFactory = new Configuration().Configure().BuildSessionFactory();
         Debug.Write("\r\n\r\n\r\nSTARTING SAMPLE");
      }

      public void Run()
      {
         CleanupEverything();        
         CreateDummyModels();
         CreateDummySalesPeople();
         LetsFindBellware();
         LetsGetAllSalesPeopleOrderedByStartDate();
         OoppsLetsDoThatAgainButExcludeInacitveEmployees();
         WootSomeoneJustMadeASale();
         CascadingUpdateOfAModelsPrice();
         LetsCreateMoreSales();
         LetsFireTheSlackers();
         LetsRewardTheTopPerformers();
         

         Console.WriteLine("All Done. Press Enter to exit");          
         Console.ReadLine();
      }

      private static void CleanupEverything()
      {
         //First thing we are doing is circumventing NHibernate and implementing database-specific SQL. 
         //Atleast it shows that you _can_ circumvent HHibernate when necessary.         

         ISession session = _sessionFactory.OpenSession();         
         ISQLQuery query = session.CreateSQLQuery("TRUNCATE TABLE Models;TRUNCATE TABLE SalesPeople;TRUNCATE TABLE Sales;");
         
         //CreateSqlQuery is typically used to SELECT data out, we need to add thi
         //we need to do this to trick it into thinking we're pulling out data (won't work for all db's)
         query.AddScalar("ignored", NHibernateUtil.Int32); 
         query.UniqueResult();

      }
      private static void CreateDummyModels()
      {
         ISession session = _sessionFactory.OpenSession();
         using (ITransaction transaction = session.BeginTransaction())
         {
            session.Save(new Model("Hummbee", "Great handling, built-in GPS to always find your way back home, Hummbee2Hummbe(tm) communication", 50000.00));
            session.Save(new Model("GasFinder", "8 cylinder off-road SUV with auto-sending gas-station meter (‘cuz you’re gonna need it!)", 33850.00));
            session.Save(new Model("Pray-Us", "It'd make more economical sense to buy your neighbout flurescent lightbulbs, but whatever", 31032.00));
            session.Save(new Model("Swift Zulian Tiger", "Raised by High Priest Thekal himself", 22744.00));
            session.Save(new Model("Bolt", "As mythical as Duke Nukem Forever", 17650.00));
            transaction.Commit();
         }
         session.Close();

         //Go to your database, type "SELECT * FROM Models" and be amazed! 
         //Ok, well maybe not amazed, but it's still a little impressive that we got data in our DB
         //without writing anything that even looks like a SQL statement
      }
      private static void CreateDummySalesPeople()
      {
         ISession session = _sessionFactory.OpenSession();
         using (ITransaction transaction = session.BeginTransaction())
         {
            session.Save(new SalesPerson("Scott", "Bellware", true, DateTime.Now.AddMinutes(-890283)));
            session.Save(new SalesPerson("Scott", "Allen", true, DateTime.Now.AddMinutes(-2974838)));
            session.Save(new SalesPerson("Jeremy", "Miller", true, DateTime.Now.AddMinutes(-74838)));
            session.Save(new SalesPerson("Greg", "Young", false, DateTime.Now.AddMinutes(-539344)));
            transaction.Commit();
         }
         session.Close();
      }
      private static void LetsFindBellware()
      {
         Console.WriteLine("Let's find Bellware");

         ISession session = _sessionFactory.OpenSession();

         SalesPerson scotticus = session.Get<SalesPerson>(1);
         Console.WriteLine("Got him! His starte date was: {0}", scotticus.StartDate);
         Console.WriteLine("\r\n");
         session.Close();

         //The Get method lets us quickly find an object based on identity
         //Get returns null if the entity isn't found, Load throws an exception
         //Load also supports lazy-loading/proxying. See Model.hbm.xml for more information
      }
      private static void LetsGetAllSalesPeopleOrderedByStartDate()
      {
         Console.WriteLine("Let's get our sales people ordered by seniority");

         ISession session = _sessionFactory.OpenSession();
         IQuery query = session.CreateQuery("from SalesPerson person order by person.StartDate");
         IList<SalesPerson> salesPeople = query.List<SalesPerson>();
         foreach(SalesPerson person in salesPeople)
         {
            Console.WriteLine("{0} has been here for {1} days", person.Alias, DateTime.Now.Subtract(person.StartDate).TotalDays);
         }
         Console.WriteLine("\r\n");
         session.Close();
         //When you write Queries, you are querying against the DOMAIN model. The StartDate property maps 
         //to the Start column (named differently specifically to highlight this point),
         //and we are writing our query against StartDate, not Start. NHibernate handles the mapping.
      }
      private static void OoppsLetsDoThatAgainButExcludeInacitveEmployees()
      {
         Console.WriteLine("Let's get our ACTIVE sales people ordered by seniority");

         ISession session = _sessionFactory.OpenSession();
         IQuery query = session.CreateQuery(@"from SalesPerson person 
                                                where person.IsActive = ?
                                                order by person.StartDate");
         query.SetBoolean(0, true); //make our first placeholder (index 0), true
         IList<SalesPerson> salesPeople = query.List<SalesPerson>();
         foreach (SalesPerson person in salesPeople)
         {
            Console.WriteLine("{0} has been here for {1} days", person.Alias, DateTime.Now.Subtract(person.StartDate).TotalDays);
         }
         Console.WriteLine("\r\n");
         session.Close();

         //we could have just made our Query "IsActive = True", but this shows how to pass in variables
      }
      private static void WootSomeoneJustMadeASale()
      {
         ISession session = _sessionFactory.OpenSession();
         SalesPerson allen = session.CreateQuery("from SalesPerson person WHERE LastName = ?").SetString(0, "Allen").UniqueResult<SalesPerson>();
         allen.AddSales(new Sale(session.Load<Model>(1), allen, DateTime.Now, 46000.00));

         using (ITransaction transaction = session.BeginTransaction())
         {            
            session.Update(allen);
            transaction.Commit();            
         }
         session.Close();
         //We could forgo using an ITransaction as long as we remember to call session.Flush() when we are done.
         //However, applications that lack any sign of planning for transactions is a plague in the .NET world.
         //Transactions are an important part of a robust data access layer, especially when using a framework
         //like NHibernate where a simple call to Save can cascade throughout your object model. Do yourself a favor
         //and learn about transactions, concurrency and locking strategies.

         //To improve performance, we're using the lazy load property of the Model class. To learn more,
         //open the Model.hbm.xml file and read the comments. In short, since we've told NHibernate to lazy-load
         //any Model entities until we actually need a value, and since in this case we don't need any value 
         //(except the Id, which we've supplied), the call to Load doesn't hit the database.
      }
      private static void CascadingUpdateOfAModelsPrice()
      {
         ISession session = _sessionFactory.OpenSession();         
         SalesPerson allen = session.CreateQuery("from SalesPerson person WHERE LastName = ?").SetString(0, "Allen").UniqueResult<SalesPerson>();
         allen.Sales[0].Model.Price -= 2000;         
         using (ITransaction transaction = session.BeginTransaction())
         {
            session.Update(allen);
            transaction.Commit();            
         }
         session.Close();   
      
         //Because we've configured our collections to cascade (via the XML mapping files), 
         //we can update the price of a model through the SalesPerson-->Sale-->Model relationship.
         //This hightlights how powerful NHibernate can be - to have tracked that a change was made,
         //and executed the necessary update.
      }

      private static void LetsCreateMoreSales()
      {        
         //just populate some random sales for the fun of it (need dummy data for the next function, not much new here)

         ISession session = _sessionFactory.OpenSession();    
         Random random = new Random();
         for (int i = 0; i < 20; ++i )
         {
            SalesPerson salesPerson = session.Load<SalesPerson>(random.Next(1, 5));
            salesPerson.Sales.Add(new Sale(session.Load<Model>(random.Next(1, 6)), salesPerson, DateTime.Now, random.Next(15000, 30000)));
            //SaveOrUpdate calls Save if it's a new instance, or update if it isn't - saves us from implementing the same boring logic
            session.SaveOrUpdate(salesPerson);
         }
         session.Flush(); //since we aren't commiting a transaction, we need to flush our session to have our changes committed
         session.Close();
      }

      private static void LetsFireTheSlackers()
      {
         Console.WriteLine("Let's get our worst performers and axe them");

         ISession session = _sessionFactory.OpenSession();
         IQuery query = session.CreateQuery(@"select person.FirstName, person.LastName, sum(sales.Price)
                     from SalesPerson person join person.Sales sales
                     group by  person.FirstName, person.LastName
                     order by sum(sales.Price)").SetMaxResults(2);
         IList<object[]> slackers = query.List<object[]>();
         foreach (object[] slacker in slackers)
         {
            Console.WriteLine("Let's fire {0} {1}", slacker[0], slacker[1]);
         }
         Console.WriteLine("\r\n");
         session.Close();

         //here we are showcasing NHQ's join ability (it also supports subquery), as well
         //as it's ability to return individual columns that don't map to a particular domain.
         //Note also that we are limiting the results to 2 objects via the SetMaxResults method of IQuery
      }
      private static void LetsRewardTheTopPerformers()
      {
         Console.WriteLine("Let's get our best performers");

         ISession session = _sessionFactory.OpenSession();
         IQuery query = session.CreateQuery(@"select new PerformanceDetail(person.FirstName, person.LastName, sum(sales.Price))
                     from SalesPerson person join person.Sales sales
                     group by person.Id, person.FirstName, person.LastName
                     order by sum(sales.Price) desc").SetMaxResults(2);
         IList<PerformanceDetail> performers = query.List<PerformanceDetail>();
         foreach (PerformanceDetail performer in performers)
         {
            Console.WriteLine("Way to go {0} {1}", performer.FirstName, performer.LastName);
         }
         Console.WriteLine("\r\n");
         session.Close();

         //This example is similar to the one above, with the main difference that we're returning
         //a typed object via the select new PerformanceDetail(...) construct. We had to tell NHibernate
         //about PerformanceDetail (see Imports.hbm.xml), and had to make sure a matching constructor existed.
      }
   }
}
