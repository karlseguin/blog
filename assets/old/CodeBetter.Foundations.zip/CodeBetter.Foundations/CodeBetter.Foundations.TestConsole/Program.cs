﻿
namespace CodeBetter.Foundations.TestConsole
{
   class Program
   {
      static void Main(string[] args)
      {
         new Sample().Run();
      }
   }
}
